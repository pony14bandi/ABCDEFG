package com.cg.banking.utility;
import java.util.Random;
public class UtilityClass {
	public static Random rand = new Random();
	public static int CUSTOMER_ID_COUNTER=111;
	public static long ACCOUNT_ID_COUNTER=10042;
	public static int TRANSACTION_ID_COUNTER=10050;

}
